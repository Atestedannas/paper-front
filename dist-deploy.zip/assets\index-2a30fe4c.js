import{_ as o,r,o as n,H as t}from"./index-269910fb.js";const c={};function s(_,a){const e=r("router-view");return n(),t(e)}const i=o(c,[["render",s]]);export{i as default};
